# Datasets
IMDB dataset
- Movies and Shows 
- This dataset provides a lot of information about movies and shows, like its rating, name, cast, genre/theme, language, etc...
- updated 1 year ago
- 5 .tsv files (rows with its attributes separated by tabs)
- 1 GB
- [Link](https://www.kaggle.com/ashirwadsangwan/imdb-dataset)

MyAnimeList
- Animes (Like movies or shows)
- This dataset provides information like its title, rating, genre/theme, etc...
- updated 3 years ago
- 9 .csv files
- 2 GB
- [Link](https://www.kaggle.com/azathoth42/myanimelist)

GoodReads
- Books
- This dataset has information about many different books, like its name, rating, genre, etc...
- updated 2 years ago
- 1 .csv file and a folder of book's images
- 2 GB (56 MB of information and the rest is images)
- [Link](https://www.kaggle.com/meetnaren/goodreads-best-books)